from setuptools import find_packages, setup

package_name = 'tb3_lab9'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ayesha',
    maintainer_email='ayesha@example.com',
    description='Lab 9 vision based target tracking using camera and OpenCV',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'camera_follower = tb3_lab9.camera_follower:main',
            'multi_color_follower = tb3_lab9.multi_color_follower:main',
        ],
    },
)
