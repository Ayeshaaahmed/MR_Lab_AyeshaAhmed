import math
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist


class WallFollowing(Node):
    def __init__(self):
        super().__init__('wall_following_node')

        self.desired_wall_distance = 0.55
        self.front_threshold = 0.45
        self.kp = 1.2

        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            qos_profile_sensor_data
        )

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        self.get_logger().info('Right wall following node started.')

    def clean_distance(self, value):
        if math.isinf(value) or math.isnan(value):
            return 3.5
        return value

    def get_regions(self, msg):
        front_values = []
        right_values = []

        for i, distance in enumerate(msg.ranges):
            distance = self.clean_distance(distance)
            angle = msg.angle_min + i * msg.angle_increment

            while angle > math.pi:
                angle -= 2.0 * math.pi

            while angle < -math.pi:
                angle += 2.0 * math.pi

            angle_deg = math.degrees(angle)

            if -15 <= angle_deg <= 15:
                front_values.append(distance)

            elif -100 <= angle_deg <= -80:
                right_values.append(distance)

        front = min(front_values) if front_values else 3.5
        right = min(right_values) if right_values else 3.5

        return front, right

    def scan_callback(self, msg):
        front, right = self.get_regions(msg)

        twist = Twist()

        if front < self.front_threshold:
            twist.linear.x = 0.0
            twist.angular.z = 0.6
            decision = 'Obstacle ahead. Turning left.'

        else:
            error = self.desired_wall_distance - right

            twist.linear.x = 0.15
            twist.angular.z = self.kp * error

            if twist.angular.z > 0.8:
                twist.angular.z = 0.8
            elif twist.angular.z < -0.8:
                twist.angular.z = -0.8

            decision = 'Following right wall.'

        self.cmd_pub.publish(twist)

        self.get_logger().info(
            f'{decision} | Front={front:.2f}, Right={right:.2f}, Angular={twist.angular.z:.2f}'
        )


def main(args=None):
    rclpy.init(args=args)
    node = WallFollowing()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    stop = Twist()
    node.cmd_pub.publish(stop)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
