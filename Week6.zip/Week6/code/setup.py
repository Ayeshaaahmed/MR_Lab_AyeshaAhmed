from setuptools import find_packages, setup

package_name = 'tb3_lab6'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ayesha',
    maintainer_email='ayesha@example.com',
    description='Lab 6 Reactive Navigation using TurtleBot3 LiDAR',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'scan_processing = tb3_lab6.scan_processing:main',
            'stop_obstacle = tb3_lab6.stop_obstacle:main',
            'obstacle_avoidance = tb3_lab6.obstacle_avoidance:main',
            'wall_following = tb3_lab6.wall_following:main',
            'reactive_sequence = tb3_lab6.reactive_sequence:main',
        ],
    },
)
