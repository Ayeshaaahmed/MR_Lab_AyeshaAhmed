import math
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan


class ScanProcessing(Node):
    def __init__(self):
        super().__init__('scan_processing_node')

        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            qos_profile_sensor_data
        )

        self.get_logger().info('Scan processing node started.')

    def clean_distance(self, value):
        if math.isinf(value) or math.isnan(value):
            return 3.5
        return value

    def get_regions(self, msg):
        front_values = []
        left_values = []
        right_values = []

        for i, distance in enumerate(msg.ranges):
            distance = self.clean_distance(distance)

            angle = msg.angle_min + i * msg.angle_increment

            while angle > math.pi:
                angle -= 2.0 * math.pi

            while angle < -math.pi:
                angle += 2.0 * math.pi

            angle_deg = math.degrees(angle)

            if -15 <= angle_deg <= 15:
                front_values.append(distance)

            elif 60 <= angle_deg <= 120:
                left_values.append(distance)

            elif -120 <= angle_deg <= -60:
                right_values.append(distance)

        front_dist = min(front_values) if front_values else 3.5
        left_dist = min(left_values) if left_values else 3.5
        right_dist = min(right_values) if right_values else 3.5

        return front_dist, left_dist, right_dist

    def scan_callback(self, msg):
        front, left, right = self.get_regions(msg)

        self.get_logger().info(
            f'Front: {front:.2f} m | Left: {left:.2f} m | Right: {right:.2f} m'
        )


def main(args=None):
    rclpy.init(args=args)
    node = ScanProcessing()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
