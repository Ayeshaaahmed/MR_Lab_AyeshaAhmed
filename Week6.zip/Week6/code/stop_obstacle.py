import math
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist


class StopOnObstacle(Node):
    def __init__(self):
        super().__init__('stop_on_obstacle_node')

        self.front_threshold = 0.45

        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            qos_profile_sensor_data
        )

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        self.get_logger().info('Stop-on-obstacle node started.')

    def clean_distance(self, value):
        if math.isinf(value) or math.isnan(value):
            return 3.5
        return value

    def get_front_distance(self, msg):
        front_values = []

        for i, distance in enumerate(msg.ranges):
            distance = self.clean_distance(distance)
            angle = msg.angle_min + i * msg.angle_increment

            while angle > math.pi:
                angle -= 2.0 * math.pi

            angle_deg = math.degrees(angle)

            if -15 <= angle_deg <= 15:
                front_values.append(distance)

        return min(front_values) if front_values else 3.5

    def scan_callback(self, msg):
        front_dist = self.get_front_distance(msg)

        twist = Twist()

        if front_dist < self.front_threshold:
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            self.get_logger().warn(f'Obstacle detected! STOP. Front = {front_dist:.2f} m')
        else:
            twist.linear.x = 0.15
            twist.angular.z = 0.0
            self.get_logger().info(f'Moving forward. Front = {front_dist:.2f} m')

        self.cmd_pub.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    node = StopOnObstacle()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    stop = Twist()
    node.cmd_pub.publish(stop)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
