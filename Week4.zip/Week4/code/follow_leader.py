#!/usr/bin/env python3
import math
import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist

class FollowLeader(Node):
    def __init__(self):
        super().__init__('follow_leader')
        self.t1 = None
        self.t2 = None

        self.create_subscription(Pose, '/turtle1/pose', self.cb1, 10)
        self.create_subscription(Pose, '/turtle2/pose', self.cb2, 10)
        self.pub = self.create_publisher(Twist, '/turtle2/cmd_vel', 10)
        self.create_timer(0.1, self.loop)

    def cb1(self, msg):
        self.t1 = msg

    def cb2(self, msg):
        self.t2 = msg

    def loop(self):
        if self.t1 is None or self.t2 is None:
            return

        dx = self.t1.x - self.t2.x
        dy = self.t1.y - self.t2.y
        dist = math.sqrt(dx * dx + dy * dy)
        target_angle = math.atan2(dy, dx)
        err = target_angle - self.t2.theta

        while err > math.pi:
            err -= 2 * math.pi
        while err < -math.pi:
            err += 2 * math.pi

        msg = Twist()
        msg.linear.x = min(2.0, 1.5 * dist)
        msg.angular.z = 4.0 * err

        if dist < 0.5:
            msg.linear.x = 0.0
            msg.angular.z = 0.0

        self.pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = FollowLeader()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
