import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge


class MultiColorFollower(Node):
    def __init__(self):
        super().__init__('multi_color_follower')

        self.image_sub = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10
        )

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.bridge = CvBridge()

        self.kp = 0.0025
        self.center_threshold = 40
        self.forward_speed = 0.10

        self.get_logger().info('Multi-color follower started.')

    def make_mask(self, hsv, color_name):
        if color_name == 'red':
            lower1 = np.array([0, 100, 100])
            upper1 = np.array([10, 255, 255])
            lower2 = np.array([160, 100, 100])
            upper2 = np.array([179, 255, 255])
            return cv2.inRange(hsv, lower1, upper1) + cv2.inRange(hsv, lower2, upper2)

        if color_name == 'blue':
            lower = np.array([100, 100, 100])
            upper = np.array([130, 255, 255])
            return cv2.inRange(hsv, lower, upper)

        if color_name == 'green':
            lower = np.array([40, 80, 80])
            upper = np.array([80, 255, 255])
            return cv2.inRange(hsv, lower, upper)

        return None

    def find_largest_object(self, mask):
        mask = cv2.erode(mask, None, iterations=2)
        mask = cv2.dilate(mask, None, iterations=2)

        contours, _ = cv2.findContours(
            mask,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE
        )

        if len(contours) == 0:
            return None, 0

        largest = max(contours, key=cv2.contourArea)
        area = cv2.contourArea(largest)

        if area < 500:
            return None, area

        return largest, area

    def image_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        height, width, _ = frame.shape
        center_x = width // 2

        twist = Twist()

        red_mask = self.make_mask(hsv, 'red')
        blue_mask = self.make_mask(hsv, 'blue')
        green_mask = self.make_mask(hsv, 'green')

        red_contour, red_area = self.find_largest_object(red_mask)
        blue_contour, blue_area = self.find_largest_object(blue_mask)
        green_contour, green_area = self.find_largest_object(green_mask)

        areas = {
            'red': red_area,
            'blue': blue_area,
            'green': green_area
        }

        detected_color = max(areas, key=areas.get)

        if areas[detected_color] < 500:
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            decision = 'No color detected. Stop.'

        elif detected_color == 'green':
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            decision = 'Green detected. Stop.'

        elif detected_color == 'blue':
            twist.linear.x = 0.0
            twist.angular.z = 0.4
            decision = 'Blue detected. Rotate left.'

        elif detected_color == 'red':
            contour = red_contour
            M = cv2.moments(contour)

            if M['m00'] != 0:
                cx = int(M['m10'] / M['m00'])
                error_x = cx - center_x

                if abs(error_x) > self.center_threshold:
                    twist.linear.x = 0.0
                    twist.angular.z = -self.kp * error_x
                    decision = 'Red detected. Aligning.'
                else:
                    twist.linear.x = self.forward_speed
                    twist.angular.z = 0.0
                    decision = 'Red centered. Moving forward.'
            else:
                decision = 'Red detected but no centroid. Stop.'
                twist.linear.x = 0.0
                twist.angular.z = 0.0

        self.cmd_pub.publish(twist)

        cv2.putText(frame, decision, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

        cv2.imshow('Multi Color Camera View', frame)
        cv2.imshow('Red Mask', red_mask)
        cv2.imshow('Blue Mask', blue_mask)
        cv2.imshow('Green Mask', green_mask)
        cv2.waitKey(1)

        self.get_logger().info(decision)


def main(args=None):
    rclpy.init(args=args)

    node = MultiColorFollower()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    stop = Twist()
    node.cmd_pub.publish(stop)

    cv2.destroyAllWindows()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
