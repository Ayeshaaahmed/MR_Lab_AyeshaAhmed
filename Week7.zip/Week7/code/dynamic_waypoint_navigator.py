import math
import sys
import time

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import FollowWaypoints


def yaw_to_quaternion(yaw):
    z = math.sin(yaw / 2.0)
    w = math.cos(yaw / 2.0)
    return z, w


class DynamicWaypointNavigator(Node):
    def __init__(self):
        super().__init__('dynamic_waypoint_navigator')
        self.client = ActionClient(self, FollowWaypoints, '/follow_waypoints')

    def make_pose(self, x, y, yaw):
        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp = self.get_clock().now().to_msg()

        pose.pose.position.x = float(x)
        pose.pose.position.y = float(y)
        pose.pose.position.z = 0.0

        z, w = yaw_to_quaternion(float(yaw))
        pose.pose.orientation.x = 0.0
        pose.pose.orientation.y = 0.0
        pose.pose.orientation.z = z
        pose.pose.orientation.w = w

        return pose

    def send_waypoints(self, waypoints):
        self.get_logger().info('Waiting for FollowWaypoints action server...')
        self.client.wait_for_server()

        goal_msg = FollowWaypoints.Goal()
        goal_msg.poses = waypoints

        self.get_logger().info(f'Sending {len(waypoints)} dynamic waypoints...')

        send_goal_future = self.client.send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self, send_goal_future)

        goal_handle = send_goal_future.result()

        if not goal_handle.accepted:
            self.get_logger().error('Dynamic waypoint goal rejected.')
            return

        self.get_logger().info('Dynamic waypoint goal accepted. Robot is navigating...')

        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)

        result = result_future.result().result

        self.get_logger().info('Dynamic waypoint mission completed.')
        self.get_logger().info(f'Missed waypoints: {result.missed_waypoints}')


def main(args=None):
    rclpy.init(args=args)

    values = sys.argv[1:]

    if len(values) == 0:
        print('Usage:')
        print('ros2 run tb3_lab7 dynamic_waypoint_navigator x1 y1 yaw1 x2 y2 yaw2 ...')
        print('Example:')
        print('ros2 run tb3_lab7 dynamic_waypoint_navigator 0.5 0.0 0.0 1.0 0.5 1.57 0.0 0.0 0.0')
        rclpy.shutdown()
        return

    if len(values) % 3 != 0:
        print('ERROR: Enter values in groups of 3: x y yaw')
        rclpy.shutdown()
        return

    navigator = DynamicWaypointNavigator()

    waypoints = []

    for i in range(0, len(values), 3):
        x = float(values[i])
        y = float(values[i + 1])
        yaw = float(values[i + 2])
        waypoints.append(navigator.make_pose(x, y, yaw))

    time.sleep(2.0)

    navigator.send_waypoints(waypoints)

    navigator.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
