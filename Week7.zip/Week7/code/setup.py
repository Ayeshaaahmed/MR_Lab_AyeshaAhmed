from setuptools import find_packages, setup

package_name = 'tb3_lab7'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ayesha',
    maintainer_email='ayesha@example.com',
    description='Lab 7 Nav2 autonomous navigation and waypoint mission planning',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'waypoint_navigator = tb3_lab7.waypoint_navigator:main',
            'dynamic_waypoint_navigator = tb3_lab7.dynamic_waypoint_navigator:main',
        ],
    },
)
