import math
import time

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import FollowWaypoints


def yaw_to_quaternion(yaw):
    z = math.sin(yaw / 2.0)
    w = math.cos(yaw / 2.0)
    return z, w


class WaypointNavigator(Node):
    def __init__(self):
        super().__init__('waypoint_navigator')
        self.client = ActionClient(self, FollowWaypoints, '/follow_waypoints')

    def make_pose(self, x, y, yaw):
        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp = self.get_clock().now().to_msg()

        pose.pose.position.x = float(x)
        pose.pose.position.y = float(y)
        pose.pose.position.z = 0.0

        z, w = yaw_to_quaternion(float(yaw))
        pose.pose.orientation.x = 0.0
        pose.pose.orientation.y = 0.0
        pose.pose.orientation.z = z
        pose.pose.orientation.w = w

        return pose

    def send_waypoints(self, waypoints):
        self.get_logger().info('Waiting for FollowWaypoints action server...')
        self.client.wait_for_server()

        goal_msg = FollowWaypoints.Goal()
        goal_msg.poses = waypoints

        self.get_logger().info(f'Sending {len(waypoints)} waypoints...')

        send_goal_future = self.client.send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self, send_goal_future)

        goal_handle = send_goal_future.result()

        if not goal_handle.accepted:
            self.get_logger().error('Waypoint goal rejected.')
            return

        self.get_logger().info('Waypoint goal accepted. Robot is navigating...')

        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)

        result = result_future.result().result

        self.get_logger().info('Waypoint mission completed.')
        self.get_logger().info(f'Missed waypoints: {result.missed_waypoints}')


def main(args=None):
    rclpy.init(args=args)

    navigator = WaypointNavigator()

    # You can change these points according to your RViz map.
    waypoints = [
        navigator.make_pose(0.5, 0.0, 0.0),
        navigator.make_pose(1.0, 0.5, 1.57),
        navigator.make_pose(1.0, -0.5, -1.57),
        navigator.make_pose(0.0, -0.5, 3.14),
        navigator.make_pose(0.0, 0.0, 0.0),
    ]

    time.sleep(2.0)

    navigator.send_waypoints(waypoints)

    navigator.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
