import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge


class CameraFollower(Node):
    def __init__(self):
        super().__init__('camera_follower')

        self.image_sub = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10
        )

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        self.bridge = CvBridge()

        # Controller parameters
        self.kp = 0.0025
        self.center_threshold = 40
        self.forward_speed = 0.10
        self.max_angular_speed = 0.6

        # Area threshold: if object is very large, robot stops
        self.close_area_threshold = 25000

        self.get_logger().info('Camera follower node started.')
        self.get_logger().info('Detecting RED colored object.')

    def image_callback(self, msg):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f'cv_bridge error: {e}')
            return

        height, width, _ = frame.shape
        image_center_x = width // 2

        # Convert BGR image to HSV
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Red color has two HSV ranges
        lower_red_1 = np.array([0, 100, 100])
        upper_red_1 = np.array([10, 255, 255])

        lower_red_2 = np.array([160, 100, 100])
        upper_red_2 = np.array([179, 255, 255])

        mask1 = cv2.inRange(hsv, lower_red_1, upper_red_1)
        mask2 = cv2.inRange(hsv, lower_red_2, upper_red_2)

        mask = mask1 + mask2

        # Remove noise
        mask = cv2.erode(mask, None, iterations=2)
        mask = cv2.dilate(mask, None, iterations=2)

        contours, _ = cv2.findContours(
            mask,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE
        )

        twist = Twist()

        if len(contours) > 0:
            largest_contour = max(contours, key=cv2.contourArea)
            area = cv2.contourArea(largest_contour)

            if area > 500:
                M = cv2.moments(largest_contour)

                if M['m00'] != 0:
                    cx = int(M['m10'] / M['m00'])
                    cy = int(M['m01'] / M['m00'])

                    error_x = cx - image_center_x

                    # Draw object on camera image
                    x, y, w, h = cv2.boundingRect(largest_contour)
                    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                    cv2.circle(frame, (cx, cy), 5, (255, 0, 0), -1)
                    cv2.line(frame, (image_center_x, 0), (image_center_x, height), (0, 255, 255), 2)

                    if area > self.close_area_threshold:
                        twist.linear.x = 0.0
                        twist.angular.z = 0.0
                        decision = 'Target close. STOP.'

                    elif abs(error_x) > self.center_threshold:
                        twist.linear.x = 0.0

                        angular = -self.kp * error_x

                        if angular > self.max_angular_speed:
                            angular = self.max_angular_speed
                        elif angular < -self.max_angular_speed:
                            angular = -self.max_angular_speed

                        twist.angular.z = angular
                        decision = 'Aligning with target.'

                    else:
                        twist.linear.x = self.forward_speed
                        twist.angular.z = 0.0
                        decision = 'Target centered. Moving forward.'

                    self.get_logger().info(
                        f'{decision} cx={cx}, error={error_x}, area={area:.0f}, '
                        f'linear={twist.linear.x:.2f}, angular={twist.angular.z:.2f}'
                    )

                else:
                    decision = 'Moment zero. Stop.'
                    twist.linear.x = 0.0
                    twist.angular.z = 0.0

            else:
                decision = 'Small object/noise ignored. Stop.'
                twist.linear.x = 0.0
                twist.angular.z = 0.0

        else:
            # Exercise 3: stop rotating when no object is detected
            decision = 'No object detected. Stop.'
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            self.get_logger().info(decision)

        self.cmd_pub.publish(twist)

        cv2.putText(
            frame,
            decision,
            (10, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (0, 255, 255),
            2
        )

        cv2.imshow('Camera View - Red Object Tracking', frame)
        cv2.imshow('Segmented Mask', mask)
        cv2.waitKey(1)


def main(args=None):
    rclpy.init(args=args)

    node = CameraFollower()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    stop = Twist()
    node.cmd_pub.publish(stop)

    cv2.destroyAllWindows()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
